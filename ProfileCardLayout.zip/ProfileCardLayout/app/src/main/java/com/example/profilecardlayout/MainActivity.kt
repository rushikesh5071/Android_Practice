package com.example.profilecardlayout

import android.annotation.SuppressLint
import android.icu.text.CaseMap.Title
import android.os.Bundle
import android.service.autofill.OnClickAction
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CardElevation
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import coil.transform.CircleCropTransformation

import com.example.profilecardlayout.ui.theme.MyTheme
import com.example.profilecardlayout.ui.theme.lightGreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyTheme {
                UsersApplication()

            }
        }
    }
}

@Composable
fun UsersApplication(userProfiles: List<UserProfile> = userProfileList) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "users_List") {

        composable("users_List") {
            MainScreen(userProfiles, navController)

        }
        composable(
            route = "user_details/{userId}",
            arguments = listOf(navArgument("userId") {
                type = NavType.IntType
            })) {navBackStackEntry ->
            UserProfileDetailsScreen(navBackStackEntry.arguments!!.getInt("userId"), navController)
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(userProfiles: List<UserProfile>, navController: NavController?) {
    Scaffold(topBar = { AppBar(
        title = "Users List",
        icon = Icons.Default.Home
        ) { }
    })
    {

        Surface(
            modifier = Modifier.fillMaxSize(),
//            color = Color.DarkGray
        ) {
            LazyColumn()
            {
                items(userProfiles) { userProfile ->
                    ProfileCard(userProfile = userProfile) {
                        navController?.navigate("user_details/${userProfile.id}")
                    }
                }

            }
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBar(title: String, icon: ImageVector, iconClickAction: () -> Unit) {
    TopAppBar(navigationIcon = {
        Icon(
            imageVector = icon,
            contentDescription= "content description",
            modifier = Modifier.padding(16.dp)
        )
    },
        title = { Text("Messaging Application Users") })
}

@Composable
fun ProfileCard(userProfile: UserProfile, clickAction:  () -> Unit ) {

    Card(
        modifier = Modifier
            .padding(top = 50.dp, bottom = 4.dp, start = 10.dp, end = 10.dp)
            .fillMaxWidth()
            .background(color = Color.White)
            .wrapContentHeight(align = Alignment.Top)
            .clickable(onClick = { clickAction.invoke() }),
        elevation= CardDefaults.cardElevation(defaultElevation=4.dp)


        ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
//            .padding(vertical = 100.dp)
                .background(color = Color.LightGray),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start,


            ) {

            ProfilePicture(userProfile.pictureUrl, userProfile.status, 72.dp)
            ProfileContent(userProfile.name, userProfile.status, Alignment.Start)

        }

    }

}

@Composable
fun ProfilePicture(imageUrl: String, onlineStatus: Boolean, imageSize: Dp) {
    val url = "https://res.cloudinary.com/demo/image/upload/v1312461204/sample.jpg"
    Card(
        shape = CircleShape,
        border = BorderStroke(width = 1.dp, color = lightGreen),
        modifier = Modifier
            .padding(1.dp)
            .size(imageSize),
       elevation =  CardDefaults.cardElevation(imageSize)

        ) {
        Image(
          // painter =  painterResource(id = drawableId),
//            painter = rememberAsyncImagePainter("https://res.cloudinary.com/demo/image/upload/v1312461204/sample.jpg"),
            painter = rememberAsyncImagePainter(
                ImageRequest.Builder(LocalContext.current).data(data =imageUrl)
                    .apply(block = fun ImageRequest.Builder.() {
                        transformations(CircleCropTransformation())
                    }).build()
            ),
            modifier = Modifier.size(72.dp).fillMaxSize(2f),
            contentDescription = "Profile Picture Description",
            contentScale = ContentScale.Crop,

        )
    }
}

@Composable
fun ProfileContent(userName: String, onlineStatus: Boolean, alignment: Alignment.Horizontal) {
    Column(
        modifier = Modifier
            .padding(30.dp),
            horizontalAlignment = alignment
    ) {
        Text(
            text = userName,
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.alpha(2f)
        )
        Text(
            text = if (onlineStatus)
                "Active now"
            else "Offline",
            style = MaterialTheme.typography.bodyLarge
        )


    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileDetailsScreen(userId: Int, navController: NavHostController?) {
    val userProfile = userProfileList.first { userProfile -> userId == userProfile.id }
    Scaffold(topBar = { AppBar(
        title = "User Profile Details",
        icon = Icons.Default.ArrowBack
    ) {
        navController?.navigateUp()
    }
    })
    {

        Surface(
            modifier = Modifier.fillMaxSize(),

            //color = Color.Cyan
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp, 70.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
                ) {

                ProfilePicture(userProfile.pictureUrl, userProfile.status, 240.dp)
                ProfileContent(userProfile.name, userProfile.status, Alignment.CenterHorizontally)
                
            }
            
        }
    }

}

@Preview(showBackground = true)
@Composable
fun UserProfileDetailsScreenPreview() {
    MyTheme {
        UserProfileDetailsScreen(userId = 0, null)
    }

}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyTheme {
        MainScreen(userProfiles = userProfileList, navController = null)
    }

}